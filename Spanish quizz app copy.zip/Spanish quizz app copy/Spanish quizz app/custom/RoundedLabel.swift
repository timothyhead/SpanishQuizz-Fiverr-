//
//  RoundedLabel.swift
//  Spanish quizz app
//
//  Created by Nick Krause on 5/19/20.
//  Copyright © 2020 Nick Krause. All rights reserved.
//

import UIKit

class RoundedLabel: UILabel {

   override func draw(_ rect: CGRect) {
         // Drawing code
         super.draw(rect)
         layer.cornerRadius = 5.0
         layer.masksToBounds = true
         
     }
    override func drawText(in rect: CGRect) {
        let newRect = rect.insetBy(dx: 8.0, dy: 8.0)
        super.drawText(in: newRect)
    }
}
