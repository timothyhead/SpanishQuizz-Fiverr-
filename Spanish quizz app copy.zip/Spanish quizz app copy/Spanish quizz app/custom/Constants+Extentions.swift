//
//  Constants+Extentions.swift
//  Spanish quizz app
//
//  Created by Nick Krause on 7/21/20.
//  Copyright © 2020 Nick Krause. All rights reserved.
//

import Foundation
import UIKit


let verbsHighscoreIdentifier = "VerbsHighscoreIdentifier"
let verbsRecentscoreIdentifier = "VerbsRecentscoreIdentifier"

let adjectivesHighscoreIdentifier = "AdjectivesHighscoreIdentifier"
let adjectivesRecentscoreIdentifier = "AdjectivesRecentscoreIdentifier"


let nounsHighscoreIdentifier = "NounsHighscoreIdentifier"
let nounsRecentscoreIdentifier = "NounsRecentscoreIdentifier"


let otherWordsAndPhrasesHighscoreIdentifier = "OtherWordsAndPhrasesHighscoreIdentifier"
let otherWordsAndPhrasesRecentscoreIdentifier = "OtherWordsAndPhrasesRecentscoreIdentifier"

let flatGreen = UIColor(red: 46/255, green: 204/255, blue: 113/255, alpha: 1.0)
let flatOrange = UIColor(red: 230/255, green: 126/255, blue: 34/255, alpha: 1.0)
let flatRed = UIColor(red: 231/255, green: 76/255, blue: 60/255, alpha: 1.0)
