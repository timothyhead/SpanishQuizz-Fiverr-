//
//  QuizloaderA.swift
//  Spanish quizz app
//
//  Created by Nick Krause on 5/23/21.
//  Copyright © 2021 Nick Krause. All rights reserved.
//

import Foundation

struct Adjective {
            let question : String
            let correctAnswer : String
            let answers : [String]
            
        }
        enum LoaderErrorA : Error {
            case dictionaryFailed, pathFailed
        }

        class QuizLoaderA {

        public func loadAdjective(forQuiz quizName: String ) throws -> [Adjective] {
            var questions = [Adjective]()
            if let path = Bundle.main.path(forResource: quizName, ofType: "plist") {
                if let dict = NSDictionary(contentsOfFile: path) {
                    let tempArray: Array = dict["Questions"]! as! [Dictionary<String,AnyObject>]
                    for dictionary in tempArray {
                        let questionToAdd = Adjective(question: dictionary["Question"] as! String,
                                                  correctAnswer: dictionary["CorrectAnswer"] as! String, answers: dictionary["Answers"] as! [String] )
                        questions.append(questionToAdd)
                    }
                    return questions
                    
                } else {
                    throw LoaderErrorA.dictionaryFailed
                }
            } else {
                throw LoaderErrorA.pathFailed
            }
            }
        

        
    }
