//
//  RoundedButton.swift
//  Spanish quizz app
//
//  Created by Nick Krause on 5/19/20.
//  Copyright © 2020 Nick Krause. All rights reserved.
//

import UIKit

class RoundedButton: UIButton {

    
    override func draw(_ rect: CGRect) {
        // Drawing code
        super.draw(rect)
        layer.cornerRadius = 5.0
        layer.masksToBounds = true
        
    }
    

}
